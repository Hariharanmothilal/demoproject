package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.example.demo.bean.UserAccountDetails;
import com.example.demo.bean.UserAccountDetailsID;

public interface UserAccountDetailsRepository extends 
JpaRepository<UserAccountDetails, UserAccountDetailsID>,
JpaSpecificationExecutor<UserAccountDetails>


{

}
