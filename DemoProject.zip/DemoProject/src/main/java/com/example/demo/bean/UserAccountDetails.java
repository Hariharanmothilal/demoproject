package com.example.demo.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="User_Account_Details")
@IdClass(UserAccountDetailsID.class)
public class UserAccountDetails {
	
	@Id
	@Column(name="PaymentId",nullable=false)
	private Integer paymentId;
	
	@Id
	@Column(name="AccountId",nullable=false)
	private Integer accountId;
	
	@Column(name="UserName",nullable=false)
	private String userName;
	
	@Id
	@Column(name="UserId",nullable=false)
	private Integer userId;
	
	@Column(name="UserFatherName",nullable=false)
	private String userFatherName;
	
	@Column(name="UserNationality",nullable=false)
	private String userNationality;

}
