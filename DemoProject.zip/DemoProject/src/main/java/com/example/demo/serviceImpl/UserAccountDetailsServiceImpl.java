package com.example.demo.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.repository.UserAccountDetailsRepository;
import com.example.demo.request.UserAccountDetailsGetReq;
import com.example.demo.response.UserAccountDetailsResponse;
import com.example.demo.service.UserAccountDetailsService;

import io.micrometer.common.util.StringUtils;
import javax.transaction.Transactional;


@Service
@Transactional
public class UserAccountDetailsServiceImpl implements UserAccountDetailsService {
	
	@Autowired
	private UserAccountDetailsRepository repo;
	
	private org.apache.logging.log4j.Logger log=LogManager.getLogger(UserAccountDetailsServiceImpl.class);
	
	@Override
	public List<Error> validatingUser(UserAccountDetailsGetReq req){
		List<Error>errorList=new ArrayList<Error>();

		try {
			
			if(req.getAccountId()!=null) {
				errorList.add(new Error("01","AccountId","please Enter the id"));
			}
			if(req.getPaymentId()!=null) {
				
			}
			if(req.getUserId()!=null) {
				
			}
			if(StringUtils.isNotBlank(req.getUserName())) {
				errorList.add(new Error("02","Error","dkfjk"));
			}
			if(StringUtils.isNotBlank(req.getUserFatherName())) {
				
			}
			if(StringUtils.isNotBlank(req.getUserNationality())) {
				
			}
			
		}catch(Exception e) {
			log.error(e);
			e.printStackTrace();
		}
		return errorList;
	}

	@Override
	public List<UserAccountDetailsResponse> getAllUser(UserAccountDetailsGetReq req) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
