package com.example.demo.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.request.UserAccountDetailsGetReq;
import com.example.demo.response.CommonResponse;
import com.example.demo.response.UserAccountDetailsResponse;
import com.example.demo.service.UserAccountDetailsService;

@RestController
@RequestMapping("/user")
public class UserAccountDetailController {
	
	@Autowired
	private UserAccountDetailsService service;
//	Get All user
	@PostMapping("/getalluser")
	public ResponseEntity<CommonResponse> getAllUser(@RequestBody UserAccountDetailsGetReq req) {
		CommonResponse data = new CommonResponse();

		List<UserAccountDetailsResponse> res = service.getAllUser(req);
		data.setCommonResponse(res);
		data.setErrorMessage(Collections.emptyList());
		data.setIsError(false);
		data.setMessage("Success");

		if (res != null) {
			return new ResponseEntity<CommonResponse>(data, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}

}
