package com.example.demo.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SuccessResponse {

	@JsonProperty("SuccessMessage")
	private String message;
	
	@JsonProperty("SuccessId")
	private String SuccessId;
}
