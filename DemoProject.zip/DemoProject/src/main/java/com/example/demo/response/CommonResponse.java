package com.example.demo.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CommonResponse {
	
	@JsonProperty("Message")
	private String message;
	
	@JsonProperty("IsError")
	private Boolean isError;
	
	@JsonProperty("ErrorMessage")
	private List<Error> errorMessage;
	
	@JsonProperty("Result")
	private Object CommonResponse;
	
	@JsonProperty("ErrorCode")
	private int errorCode;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean getIsError() {
		return isError;
	}

	public void setIsError(boolean b) {
		this.isError = b;
	}

	public List<Error> getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(List<Error> errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Object getCommonResponse() {
		return CommonResponse;
	}

	public void setCommonResponse(Object commonResponse) {
		CommonResponse = commonResponse;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

}
