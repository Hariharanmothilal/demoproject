package com.example.demo.service;

import java.util.List;

import com.example.demo.request.UserAccountDetailsGetReq;
import com.example.demo.response.UserAccountDetailsResponse;

public interface UserAccountDetailsService {

	List<Error> validatingUser(UserAccountDetailsGetReq req);

	List<UserAccountDetailsResponse> getAllUser(UserAccountDetailsGetReq req);

}
