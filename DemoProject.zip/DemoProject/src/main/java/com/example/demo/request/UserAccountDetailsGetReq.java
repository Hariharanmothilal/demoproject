package com.example.demo.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class UserAccountDetailsGetReq {
	
	@JsonProperty("PaymentId")
	private Integer paymentId;
	
	@JsonProperty("AccountId")
	private Integer accountId;
	
	@JsonProperty("UserName")
	private String userName;
	
	
	@JsonProperty("UserId")
	private Integer userId;
	
	@JsonProperty("UserFatherName")
	private String userFatherName;
	
	@JsonProperty
	("UserNationality")
	private String userNationality;

	public Integer getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUserFatherName() {
		return userFatherName;
	}

	public void setUserFatherName(String userFatherName) {
		this.userFatherName = userFatherName;
	}

	public String getUserNationality() {
		return userNationality;
	}

	public void setUserNationality(String userNationality) {
		this.userNationality = userNationality;
	}


}
