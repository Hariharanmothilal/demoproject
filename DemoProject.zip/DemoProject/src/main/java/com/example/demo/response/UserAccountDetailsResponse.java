package com.example.demo.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class UserAccountDetailsResponse {
	
	@JsonProperty("PaymentId")
	private Integer paymentId;
	
	@JsonProperty("AccountId")
	private Integer accountId;
	
	@JsonProperty("UserName")
	private String userName;
	
	
	@JsonProperty("UserId")
	private Integer userId;
	
	@JsonProperty("UserFatherName")
	private String userFatherName;
	
	@JsonProperty
	("UserNationality")
	private String userNationality;


}
